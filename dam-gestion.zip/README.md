# dam-gestion

Actividad Individual 1 de Desarrollo de Interfaces (DAM).

Proyecto Ionic y Angular en proceso. Esta entrega recoge el estado inicial del proyecto y la puesta en marcha del servidor de desarrollo.

## Memoria de prácticas

[Descargar la memoria en PDF](docs/Memoria_Actividad_Individual_1.pdf)

## Ejecutar el proyecto

Con Node.js, npm e Ionic CLI instalados:

```sh
npm ci
ionic serve
```

La aplicación estará disponible en http://localhost:8100.

Las carpetas de dependencias y caché no se incluyen en el repositorio.
